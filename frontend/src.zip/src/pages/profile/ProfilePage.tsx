import { useEffect, useState } from 'react'

import { getPreferences, updatePreferences } from '../../entities/user/api/preferences.api'
import { getCapabilities } from '../../entities/user/api/capabilities.api'

export function ProfilePage() {
    const [prefs, setPrefs] = useState<any>(null)
    const [caps, setCaps] = useState<any>(null)

    useEffect(() => {
        getPreferences().then(setPrefs)
        getCapabilities().then(setCaps)
    }, [])

    if (!prefs || !caps) return <div>Загрузка...</div>

    return (
        <div className="page">
            <div className="card">
                <h2>Настройки</h2>

                <select
                    value={prefs.default_search_mode}
                    onChange={(e) =>
                        setPrefs({ ...prefs, default_search_mode: e.target.value })
                    }
                >
                    <option value="lexical">Лексический</option>
                    <option value="semantic">Семантический</option>
                    <option value="semantic_llm">С LLM</option>
                </select>

                {caps.llm_providers.map((p: any) => (
                    <label key={p.code}>
                        <input
                            type="radio"
                            disabled={!p.enabled}
                            checked={prefs.preferred_llm_provider === p.code}
                            onChange={() =>
                                setPrefs({ ...prefs, preferred_llm_provider: p.code })
                            }
                        />
                        {p.label} {!p.enabled && '(недоступно)'}
                    </label>
                ))}

                <button
                    className="button"
                    onClick={() => updatePreferences(prefs)}
                >
                    Сохранить
                </button>
            </div>
        </div>
    )
}